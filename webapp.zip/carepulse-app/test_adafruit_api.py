import requests

# Adafruit IO-konfiguration
AIO_USERNAME = "ismo0001"
AIO_KEY = "aio_Lzmz73ZIOrnNWRSpId9lTfMZgrJt"
FEED_NAME = "pulse"

# Send ny værdi til feedet
def update_feed(value):
    url = f"https://io.adafruit.com/api/v2/{AIO_USERNAME}/feeds/{FEED_NAME}/data"
    headers = {"X-AIO-Key": AIO_KEY}
    payload = {"value": value}

    response = requests.post(url, headers=headers, json=payload)
    if response.status_code == 200:
        print(f"Værdi opdateret til: {value}")
    else:
        print(f"Fejl ved opdatering: {response.status_code} - {response.text}")

# Opdater feedet med ny værdi (fx 80)
update_feed(80)
