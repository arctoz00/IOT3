from flask import Flask, render_template, jsonify, send_from_directory, request
from flask_sqlalchemy import SQLAlchemy
import requests  # Til at kommunikere med Adafruit IO
import os        # <-- Til at vise, hvor Flask kører henne

app = Flask(__name__)

# Database Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
db = SQLAlchemy(app)

# Adafruit IO Configuration
AIO_USERNAME = "ismo0001"
AIO_KEY = "aio_Lzmz73ZIOrnNWRSpId9lTfMZgrJt"
FEED_NAME = "pulse"  # Skal matche dit feed på Adafruit IO

# Database Model
class VitalData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    pulse = db.Column(db.Integer, nullable=False)
    motion = db.Column(db.String(100), nullable=False)

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/manifest.json')
def manifest():
    return send_from_directory('static', 'manifest.json')

@app.route('/service-worker.js')
def service_worker():
    return send_from_directory('static', 'service-worker.js')

# Route for at hente den SENESTE data fra Adafruit IO (pulse) OG gemme lokalt
@app.route('/data')
def get_data():
    url = f"https://io.adafruit.com/api/v2/{AIO_USERNAME}/feeds/{FEED_NAME}/data/last"
    headers = {"X-AIO-Key": AIO_KEY}

    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            pulse_value = data.get("value", None)

            # Gem i databasen, hvis der er data
            if pulse_value is not None:
                try:
                    pulse_int = int(pulse_value)  # hvis værdien er et tal
                except ValueError:
                    # Hvis det ikke er et heltal, kan du bestemme, hvad der skal ske
                    pulse_int = 0

                vital_record = VitalData(pulse=pulse_int, motion="NA")
                db.session.add(vital_record)
                db.session.commit()

            return jsonify({
                "pulse": data.get("value", "Ingen data"),
                "timestamp": data.get("created_at", "Ukendt tidspunkt")
            })
        else:
            return jsonify({"error": "Kunne ikke hente data fra Adafruit IO"}), response.status_code
    except Exception as e:
        return jsonify({"error": "Fejl under forbindelse til Adafruit IO", "details": str(e)})

# Route for at SENDE data til Adafruit IO (pulse)
@app.route('/send-data', methods=['POST'])
def send_data():
    value = request.json.get("value", 80)
    url = f"https://io.adafruit.com/api/v2/{AIO_USERNAME}/feeds/{FEED_NAME}/data"
    headers = {"X-AIO-Key": AIO_KEY}
    payload = {"value": value}

    try:
        response = requests.post(url, headers=headers, json=payload)
        if response.status_code == 200:
            return jsonify({"message": "Data sendt til Adafruit IO!"})
        else:
            return jsonify({
                "error": "Kunne ikke sende data",
                "details": response.text
            }), response.status_code
    except Exception as e:
        return jsonify({"error": "Fejl under forbindelse til Adafruit IO", "details": str(e)})

# Route for at hente al data fra den lokale database
@app.route('/local-data')
def local_data():
    all_data = VitalData.query.all()
    return jsonify([
        {
            "id": d.id,
            "pulse": d.pulse,
            "motion": d.motion
        }
        for d in all_data
    ])

if __name__ == '__main__':
    # Opret tabeller i databasen, hvis de ikke findes.
    with app.app_context():
        db.create_all()

    # Kør Flask (uden SSL) og gør det tilgængeligt på netværket
    app.run(host='192.168.0.64', port=5000, debug=True)
